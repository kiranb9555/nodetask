import mongoose from "mongoose";

const movieSchema = mongoose.Schema({
    title:{
        type:String,
        required:true
    },
    description:{
        type:String,
        required:true,
        trim:true
    },
    release_date:{
        type:String,
        required:true,
    },
    director:{
        type:String,
        required:true,
    }
},{timestamps:true});


export default mongoose.model('Movie',movieSchema)