import mongoose from "mongoose";

const userSchema = mongoose.Schema({
    user_name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true,
        trim:true,
    },
    password:{
        type:String,
        required:true,
        minlength:6,
    },
    reset_token:{
        type:String,
    }
},{timestamps:true});


export default mongoose.model('User',userSchema)