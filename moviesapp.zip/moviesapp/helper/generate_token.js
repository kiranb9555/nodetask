import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config();

function jwtToken(id) {
	const token = jwt.sign(
		{
			user_id: id
		},
		process.env.JWT_SECRET,
		{
			expiresIn: "10d",
		}
	);
	return token;
}
export default jwtToken;