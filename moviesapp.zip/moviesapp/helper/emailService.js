import nodemailer from 'nodemailer'

export async function emailService(data) {
    console.log(data,'data')
    const smtpService = "smtp.mailtrap.io";
	const senderAddress = process.env.EMAIL_FROM;
	const transporter = nodemailer.createTransport({
		host: smtpService,
        port: 2525,
        auth: {
            user: "9e966921febece",
            pass: "1e8865093549de"
        }
	});
	let mailOptions = {
		from: senderAddress,
		to: data.ToAddresses,
		subject: data.Message.Subject.Data,
		cc: data.cc,
		bcc: data.bcc,
		html: data.Message.Body.Html.Data
	};
	let info = await transporter.sendMail(mailOptions);

	if (info) {
		return { status: 1 };
	} else {
		return { status: 0 };
	}
}