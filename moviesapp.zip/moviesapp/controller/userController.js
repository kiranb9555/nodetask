import { changePassword, forgotPassword, login, register } from "../service/user.js";



export const userRegister = async(req,res) =>{
    try {
		const result = await register(req.body);
		res.status(201).json({data:result,message:'User Registered successfully'});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}

export const userLogin = async(req,res) =>{
    try {
		const result = await login(req.body);
		res.status(201).json({data:result,message:'Login successfully'});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}

export const userForgotPassword = async(req,res) =>{
    try {
		const result = await forgotPassword(req.body);
		res.status(201).json({data:result,message:'Email sent successfully'});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}

export const userChangePassword = async(req,res) =>{
    try {
		const result = await changePassword(req.body);
		res.status(201).json({data:result,message:'Password Changed successfully'});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}