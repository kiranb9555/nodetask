import { addNewMovie,getAllMovie,getMovieByid,getMovieByPagination } from "../service/movie.js";


export const addMovie = async(req,res) =>{
    try {
		const result = await addNewMovie(req.body);
		res.status(201).json({data:result,message:'Movie added successfully'});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}

export const getMovie = async(req,res) =>{
    try {
		const result = await getAllMovie();
		res.status(200).json({data:result});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}

export const getByid = async(req,res) =>{
    try {
		const result = await getMovieByid(req.params);
		res.status(200).json({data:result});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}

export const movieByPagination = async(req,res) =>{
    try {
		const result = await getMovieByPagination(req.query);
		res.status(200).json({data:result});
	} catch (error) {
		res.status(404).json({ error: { message: error.message } });
	}
}