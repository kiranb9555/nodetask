import Movie from "../model/Movie.js"

export const addNewMovie = async(body) => {
  
  let movie = new Movie({
    title:body.title,
    description:body.description,
    release_date:body.release_date,
    director:body.director
  })
  let result = await movie.save();
  return result;
}

export const getAllMovie = async() => {
  
  let result = await Movie.find({});
   if(!result.length > 0){
    throw new Error(`No Movies found!`);
   }
   return result;
}


export const getMovieByid = async(params) => {

  let result = await Movie.findOne({_id:params.id});
  return result;
}

export const getMovieByPagination = async(query) => {

  const dataPerPage = query.size || 10 ;
  const page        = query.page || 1 ;

  let result = await Movie.find({}).skip(dataPerPage * page - dataPerPage).limit(dataPerPage);

  if(!result.length > 0){
    throw new Error(`No Movies found!`);
   }
   
  return result;
}