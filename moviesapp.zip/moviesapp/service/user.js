import bcrypt from "bcrypt";
import { emailService } from "../helper/emailService.js";
import jwtToken from "../helper/generate_token.js";
import User from "../model/User.js";


export const register = async(body) => {

    const {user_name,email,password} = body;

    if(!user_name || !email || !password){
        throw new Error(`All Fields are mandatory`)
    }

    // check if user already exists
    const isUserAlreadyExist = await User.findOne({email:email});

    if(isUserAlreadyExist){
        throw new Error(`User Already Exist.Please Login!`)
    }

    // hash Passoword before save Db
    const salt = await bcrypt.genSalt(10);
	const hashPassword = await bcrypt.hash(password, salt);

    const user = new User({
        user_name: user_name,
        email: email,
        password: hashPassword
    });
    await user.save();

    // Generate Jsonweb token
    const token = jwtToken(user._id);
    const user_data = {...user._doc,token:token};
    const {password:userPassword,...restData} = user_data;
    return restData;
}


export const login = async(body) => {
    const {email,password} = body;
    
    if(!email || !password){
        throw new Error(`All Fields are mandatory`)
    }

    const user = await User.findOne({email:email});

    if(!user){
        throw new Error(`User does not Exist.Please Register!`)
    }
    const comparePassword = await bcrypt.compare(password, user.password);

    if(!comparePassword){
        throw new Error(`Password does not match!`)
    }

    const token = jwtToken(user._id);
    const user_data = {...user._doc,token:token};
    const {password:userPassword,...restData} = user_data;

    return restData;
}

export const forgotPassword = async(body) => {
    const {email} = body;

    const user = await User.findOne({email:email});

    if(!user){
        throw new Error('Email not present')
    }
    
    const generateRandomNumber = Math.floor(1000000 + Math.random() * 9000000)

    await User.updateOne(
        {email:email},
        {$set:{reset_token:generateRandomNumber}}
        )

    const user_data = await User.findOne({email:email});

        const params = {
            Source: process.env.EMAIL_FROM,
            ToAddresses: [body.email],
            cc: null,
            bcc: null,
            ReplyToAddresses: [process.env.EMAIL_TO],
            Message: {
                Body: {
                    Html: {
                        Charset: "UTF-8",
                        Data: `<html>
                        <body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
                        <!--100% body table-->
                        <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
                            style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
                            <tr>
                                <td>
                                    <table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0"
                                        align="center" cellpadding="0" cellspacing="0">
                                      <td>
                                        <tr>
                                            <td style="height:80px;">&nbsp;</td>
                                        </tr>
                                        
                                        <tr>
                                            <td style="height:20px;">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"
                                                    style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                                  <td >
                                                  <a href="">
                                                </a>
                                              <h3 style="margin-left:-391px!important;font-size:20px">Reset Password</h3>
                                            </td>
                                                    <tr>
                                                        <td style="height:40px;">&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                        <td style="padding:0 35px;">
                                                            <p style="color:#1e1e2d; font-weight:100; margin:0;font-size:15px;font-family:'Rubik',sans-serif;"> Dear User,
                    We're sending you this email because you requested a password reset. Click on this link to create a new password:</p>
                                                                <a href="${process.env.FRONT_APP_URL}/auth/changepassword/${user_data.reset_token}"
                                                                style="background:#ff9668;text-decoration:none !important; font-weight:500; margin-top:35px; color:#fff;text-transform:uppercase; font-size:14px;padding:10px 24px;display:inline-block;border-radius:50px;">Reset
                                                                Password
                                                                </a>
                                                            
                                                            <p style="color:#1e1e2d; font-size:15px;line-height:24px; margin: 16px 0px 0px 0px;">
                                                                If you didn't request a password, you can ignore this email, Your password will not be changed.
                                                            </p>
                                                            
                                                            
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="height:40px;">&nbsp;</td>
                                                    </tr>
                                                </table>
                                            </td>
                                        <tr>
                                            <td style="height:20px;">&nbsp;</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <!--/100% body table-->
                    </body>
                                </html>`
                    }
                },
                Subject: {
                    Charset: "UTF-8",
                    Data: "Password Reset"
                }

            }
        };
        try {
            await emailService(params);
        } catch (e) {
           throw new Error("There is something wentwrong please try again later");
        }
}


export const changePassword = async(body) => {
    
    const {email,reset_token,password,confirm_password} = body;

    const get_data = await User.findOne({
		$and: [{ reset_token: reset_token }, { email: email }]
	}).lean();
   
	const salt = await bcrypt.genSalt(10);
	const confirmPassword = await bcrypt.hash(confirm_password, salt);
	const newPassword = await bcrypt.hash(password, salt);
    if(get_data){
			if (newPassword === confirmPassword) {
                await User.updateOne(
                    {$and: [{ reset_token: reset_token }, { email: email }]},
                    {
                        $set: {
                            password: newPassword,
                        }
                    }
                );
            }
            else{
                throw new Error('Password and Confirmpassword does not match')
            }
    }
}