import express from 'express';
import { userRegister,userLogin,userForgotPassword, userChangePassword } from '../controller/userController.js';

const router = express.Router();

router.post('/register', userRegister);
router.post('/login', userLogin);
router.post('/forgotpassword', userForgotPassword);
router.post('/changepassword', userChangePassword);

export default router;