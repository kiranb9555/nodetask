import express from 'express';
import { addMovie,getMovie,getByid,movieByPagination } from '../controller/movieController.js';

const router = express.Router();

router.get('/', getMovie);
router.get('/:id', getByid);
router.post('/add', addMovie);
router.post('/paginated', movieByPagination);


export default router;