import express from "express";
import dotenv from 'dotenv';
import http from 'http';
import connectDb from './config/db.js';
import {Server}  from "socket.io";
import redis from 'redis';
import path from 'path';
// import { createAdapter } from "@socket.io/redis-adapter";


// const { createClient } = redis;

// Routes
import movieRoutes from './routes/movie.js';
import userRoutes from './routes/user.js';

import { userJoin,getCurrentUser,userLeave,getRoomUsers } from "./utils/users.js";
import formatMessage from "./utils/messages.js";

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Set static folder
const __dirname = path.resolve();
app.use(express.static(path.join(__dirname, "public")));

dotenv.config();
connectDb();

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const botName = "Socket Io Bot";

app.use('/api/movie',movieRoutes);
app.use('/api/user',userRoutes);

io.on("connection", (socket) => {
    socket.on("joinRoom", ({ username, room }) => {
      const user = userJoin(socket.id, username, room);
  
      socket.join(user.room);
  
      // Welcome current user
      socket.emit("message", formatMessage(botName, "Welcome to Socket IO App!"));
  
      // Broadcast when a user connects
      socket.broadcast
        .to(user.room)
        .emit(
          "message",
          formatMessage(botName, `${user.username} has joined the chat`)
        );
  
      // Send users and room info
      io.to(user.room).emit("roomUsers", {
        room: user.room,
        users: getRoomUsers(user.room),
      });
    });
  
    // Listen for chatMessage
    socket.on("chatMessage", (msg) => {
      const user = getCurrentUser(socket.id);
  
      io.to(user.room).emit("message", formatMessage(user.username, msg));
    });
  
    // Runs when client disconnects
    socket.on("disconnect", () => {
      const user = userLeave(socket.id);
  
      if (user) {
        io.to(user.room).emit(
          "message",
          formatMessage(botName, `${user.username} has left the chat`)
        );
  
        // Send users and room info
        io.to(user.room).emit("roomUsers", {
          room: user.room,
          users: getRoomUsers(user.room),
        });
      }
    });
  });

  server.listen(process.env.PORT || 5000 , () => {
    console.log(`server is running on ${process.env.PORT}`)
})